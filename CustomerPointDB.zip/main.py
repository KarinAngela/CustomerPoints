conn = mysql.connector.connect(
    host="localhost:8080",
    user="karin",
    password="0411",
    database="API"
)