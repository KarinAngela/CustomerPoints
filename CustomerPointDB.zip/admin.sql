create table Admin (
	id int auto_increment not null,
	nome varchar(100), 
	cpf varchar (100) not null, 
	data_nascimento varchar(100),
	primary key(id)
);